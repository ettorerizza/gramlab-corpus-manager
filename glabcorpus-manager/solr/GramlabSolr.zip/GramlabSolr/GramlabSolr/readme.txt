== Description ==
Gramlabcorpus est un outil de gestion de diffusion de corpus de documents destin�s � l'outil gramlab.
Gramlabcorpus est une application web coupl�e � un moteur d'indexation solr.

== Pr�alable ==
Gramlab corpus �tant une web app il s'�x�cute dans le contexte d'un serveur Web prenons ici Tomcat par example.
Il faut installer tomcat en pr�requis � toutes les op�rations suivantes.
Pour windows:
	http://tomcat.apache.org/download-70.cgi
	prendre le "32-bit/64-bit Windows Service Installer" qui est un instaler automatique il suffit alors de l'ex�cuter et tomcat sera installer le repertoire
    "C:\Program Files\"

== installation ==
GramlabCorpus se pr�sente en deux paquets:
 -> GLabCorpus.war qui est l'application web. Il copier coller ce fichier dans le repertoire webapp de Tomcat, en prenant l'installation ci-dessus nous
    trouverons webapp dans le repertoire  "C:\Program Files\Apache Software Foundation\Tomcat 7.0\webapps". Au lancement de tomcat ce fichier sera deploy� automatiquement.
 
 -> GramlabSolr.zip: ce zip contient le moteur d'indexation sous trois fichier, solr.war,solr.xml,GramlabSolr.xml. Il faut dezipper dans un repertoire de
    votre choix, par example "C:\RepertoireGramlab". Vous aurez alors dans ce repertoire une repertoire  GramlabSolr contentant ces fichiers.
	
	Copier GramlabSolr.xml dans le repertoire localhost de tomcat, toujours dans ce cas de figure on trouvera ce fichier.
	"C:\Program Files\Apache Software Foundation\Tomcat 7.0\conf\Catalina\localhost". 
	Editer ce fichier : GramlabSolr.xml
	Initialement  "<?xml version="1.0" encoding="utf-8"?>
                  <Context path="/GramlabSolr" docBase="C:\RepertoireGramlab\GramlabSolr\solr.war" debug="0" crossContext="true">
                  <Environment name="solr/home" type="java.lang.String" value="C:\RepertoireGramlab\GramlabSolr" override="true"/>
                  </Context>"
	Les entr�es docBase et value doivent pointer vers votre repertoire GramlabSolr.
	
 -> D�marrer Tomcat
    localhost:8080/GLabCorpus/index.html
	
== Configuration ==
   Le GLabCorpus.war est d�ploy� dans tomat en un repertoire GLabCorpus.
   Il contient dans conf le fichier de configuration "glabcorpus.properties".
	corpus_home=C:\RepertoireGramlab
	data_home=C:\RepertoireGramlab\sandbox
	solr_server=http://localhost:8080/GramlabSolr/
	solr_core=gramlab
	
	corpus_home l'endroit ou reside votre application sur le disque
	data_home: l'endoit ou il va stocker les fichiers natifs du corpus
	solr_server: l'adresse du serveur solr
	solr_core: le nom de la base
        